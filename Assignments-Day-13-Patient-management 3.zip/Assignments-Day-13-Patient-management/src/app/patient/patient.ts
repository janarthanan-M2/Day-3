export class Patient {
    id: number | any;
    name: string | any;
    disease: string | any;
    doc: string | any;
    stage: string | any;
}
