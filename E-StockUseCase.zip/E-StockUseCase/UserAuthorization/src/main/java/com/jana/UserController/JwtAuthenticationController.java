package com.jana.UserController;

import com.jana.UserConfiguration.JwtTokenUtil;
import com.jana.UserModel.JwtRequest;
import com.jana.UserModel.JwtResponse;
import com.jana.UserModel.UserDao;
import com.jana.UserModel.UserDto;
import com.jana.UserRepository.UserRepository;
import com.jana.UserService.JwtUserDetailsService;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
public class JwtAuthenticationController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private JwtUserDetailsService userDetailsService;
	
	@Autowired
	private UserRepository repo;

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {

		authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());

		final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());

		final String token = jwtTokenUtil.generateToken(userDetails);
		
		final String userName=jwtTokenUtil.getUsernameFromToken(token);
		System.out.println("username is"+userName);
		final String role = userDetailsService.getrole(userName);
		System.out.println("user role is"+role); 

		return ResponseEntity.ok(new JwtResponse(token,role));
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ResponseEntity<?> saveUser(@RequestBody @Valid UserDto user) throws Exception {
		return ResponseEntity.ok(userDetailsService.save(user));
	}

	private void authenticate(String username, String password) throws Exception {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new Exception("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new Exception("INVALID_CREDENTIALS", e);
		}
	}
	
	@PostMapping("/authorize")
	public boolean authorize(@RequestHeader("Authorization") String token) {
		String authToken = null;
		String user = null;
		if(token!=null && token.startsWith("Bearer ")) {
			authToken = token.substring(7);
			user = jwtTokenUtil.getUsernameFromToken(authToken);
		}
		
		if(user == null) {
			System.out.println(user);
			return false;
		}
		System.out.println(user);
		return true;
	}
	
	@PostMapping("/getrole")
	public String getrole(@RequestHeader("Authorization") String token) {
		String authToken = null;
		String user = null;
		if(token!=null && token.startsWith("Bearer ")) {
			authToken = token.substring(7);
			user = jwtTokenUtil.getUsernameFromToken(authToken);
		}
		else {
			return "";
		}
		return userDetailsService.getrole(user);
	}
//	
	@GetMapping("/getmails/{role}")
	public List<String> getmails(@PathVariable String role){
		List<UserDao> li=new ArrayList<UserDao>();
		li=repo.findByRole(role);
		List<String> list=new ArrayList<String>();	
		for(int i=0;i < li.size();i++) {
			list.add(li.get(i).getEmail());
		}
		return list;
	}
	
}
