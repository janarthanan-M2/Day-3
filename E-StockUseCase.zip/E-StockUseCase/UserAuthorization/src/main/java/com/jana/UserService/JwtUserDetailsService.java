package com.jana.UserService;

import com.jana.UserModel.UserDao;
import com.jana.UserModel.UserDto;
import com.jana.UserRepository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class JwtUserDetailsService implements UserDetailsService {
	@Autowired
	private UserRepository userDao;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserDao user = userDao.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
				new ArrayList<>());
	}

	public UserDao save(UserDto user) {
		System.out.println(user);
		int salary = user.getSalary()*12;
		UserDao newUser = new UserDao();
		newUser.setUsername(user.getUsername());
		newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		newUser.setFirstname(user.getFirstname());
		newUser.setLastname(user.getLastname());
		newUser.setAddress(user.getAddress());
		newUser.setState(user.getState());
		newUser.setEmail(user.getEmail());
		newUser.setPan(user.getPan());
		newUser.setContact(user.getContact());
		newUser.setDob(user.getDob());
		newUser.setRole(user.getRole());
		newUser.setSalary(user.getSalary());
		
		if(salary <= 500000) {
			newUser.setUsertype("A");
		}
		else if(salary <=1000000 && salary>=500000) {
			newUser.setUsertype("B");
		}
		else if(salary <=1500000 && salary>=1000000) {
			newUser.setUsertype("C");
		}
		else if(salary <=3000000 && salary>=1500000) {
			newUser.setUsertype("D");
		}
		else  {
			newUser.setUsertype("E");
		}
		
		return userDao.save(newUser);
	}
	
	public String getrole(String user) {
		UserDao usd = new UserDao();
		usd = userDao.findByUsername(user);
		return usd.getRole();
		
	}

	
}