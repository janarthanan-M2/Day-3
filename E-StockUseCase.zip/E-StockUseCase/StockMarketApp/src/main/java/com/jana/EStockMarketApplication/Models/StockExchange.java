package com.jana.EStockMarketApplication.Models;

public enum StockExchange {
    NSE,
    BSE
}
