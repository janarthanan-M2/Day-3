package com.jana.EStockMarketApplication.Service;

import com.jana.EStockMarketApplication.Models.StockPrice;
import org.springframework.stereotype.Service;

public interface StockPriceService {
    void UpdateStockPrice(long companyCode, StockPrice newPrice);
}
