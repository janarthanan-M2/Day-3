export class Patient {
    id?: number | any;
    firstName: string | any;
    lastName: string | any;
}
