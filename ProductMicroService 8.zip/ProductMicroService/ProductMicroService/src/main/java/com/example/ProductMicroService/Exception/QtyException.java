package com.example.ProductMicroService.Exception;

public class QtyException extends RuntimeException{
    public QtyException(String msg)
    {
        super(msg);
    }
}
