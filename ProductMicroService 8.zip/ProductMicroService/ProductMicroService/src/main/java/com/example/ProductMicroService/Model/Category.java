package com.example.ProductMicroService.Model;

public enum Category {
    Dairy,
    Pharma,
    Produce
}
