package com.example.ProductMicroService.Exception;

public class NameException extends RuntimeException{
    public NameException(String msg)
    {
        super(msg);
    }
}
