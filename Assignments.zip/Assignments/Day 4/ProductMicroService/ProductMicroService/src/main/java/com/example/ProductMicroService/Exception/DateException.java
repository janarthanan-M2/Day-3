package com.example.ProductMicroService.Exception;

public class DateException extends RuntimeException{
    public DateException(String msg)
    {
        super(msg);
    }
}
