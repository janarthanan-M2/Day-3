package com.example.circular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircularApplicationTests {

	@Test
	void contextLoads() {
	}

}
