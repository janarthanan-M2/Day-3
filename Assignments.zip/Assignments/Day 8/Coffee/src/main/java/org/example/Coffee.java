package org.example;

public interface Coffee {

    double cost();
    String description();
}
