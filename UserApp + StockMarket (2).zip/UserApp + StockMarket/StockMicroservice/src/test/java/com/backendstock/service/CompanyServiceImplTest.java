package com.backendstock.service;

import com.backendstock.DTOs.CompanyResponseDTO;
import com.backendstock.exception.CompanyNotFound;
import com.backendstock.model.Company;
import com.backendstock.repository.CompanyRepository;
import com.backendstock.repository.StockPriceRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CompanyServiceImplTest {
    @Mock
    private CompanyRepository companyRepository;

    @Mock
    private StockPriceRepository stockPriceRepository;

    @InjectMocks
    private CompanyServiceImpl companyService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterCompany() {
        Company company = new Company();
        company.setCompanyTurnover(100000000);

        when(companyRepository.save(any(Company.class))).thenReturn(company);
        Company result = companyService.RegisterCompany(company);
        assertNotNull(result);
        assertEquals(company, result);
    }

    @Test
    void testGetAllCompanies() {
        when(companyRepository.findAll()).thenReturn(new ArrayList<>());
        List<CompanyResponseDTO> result = companyService.getAllCompanies();

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetCompanyByID() {
        Long companyCode = 1L;
        Company company = new Company();

        when(companyRepository.findById(companyCode)).thenReturn(Optional.of(company));

        Optional<CompanyResponseDTO> result = companyService.getCompanyByID(companyCode);

        assertTrue(result.isPresent());
        assertEquals(company.getCompanyName(), result.get().getCompanyName());

    }

    @Test
    void testUpdateCompanyNotFound() {
        Long companyCode = 1L;
        Company updatedCompany = new Company();

        when(companyRepository.findById(companyCode)).thenReturn(Optional.empty());

        assertThrows(CompanyNotFound.class, () -> companyService.UpdateCompany(companyCode, updatedCompany));
    }

    @Test
    void testDeleteCompany() {
        Long companyCode = 1L;
        Company company = new Company();

        when(companyRepository.findById(companyCode)).thenReturn(Optional.of(company));

        boolean result = companyService.deleteCompany(companyCode);

        assertTrue(result);
    }

    @Test
    void testDeleteCompanyNotFound() {
        Long companyCode = 1L;
        when(companyRepository.findById(companyCode)).thenReturn(Optional.empty());
        assertThrows(CompanyNotFound.class, () -> companyService.deleteCompany(companyCode));
    }
}
