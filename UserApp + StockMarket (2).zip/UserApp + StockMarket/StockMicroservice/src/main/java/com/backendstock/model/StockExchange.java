package com.backendstock.model;

public enum StockExchange {
    NSE,
    BSE
}
