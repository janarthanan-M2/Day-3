package com.backendstock.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name="authorization-microservice",value = "authorization-microservice",url="http://3.149.237.156:8080")
public interface AuthorizeClient {
    @PostMapping("/authorize")
    public boolean authorize(@RequestHeader("Authorization")String token);

    @PostMapping("/getrole")
    public String getrole(@RequestHeader("Authorization")String token);


}
