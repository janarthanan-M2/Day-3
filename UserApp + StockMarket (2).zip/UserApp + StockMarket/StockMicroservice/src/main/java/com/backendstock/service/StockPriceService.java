package com.backendstock.service;

import com.backendstock.model.StockPrice;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;

public interface StockPriceService {
    void UpdateStockPrice(long companyCode, StockPrice newPrice);
}
