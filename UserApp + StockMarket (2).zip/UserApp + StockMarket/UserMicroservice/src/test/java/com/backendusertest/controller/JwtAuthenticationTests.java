package com.backendusertest.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import java.util.Optional;
import com.backenduser.controller.JwtAuthentication;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetails;
import com.backenduser.jwt.JwtTokenUtil;
import com.backenduser.model.JwtRequest;
import com.backenduser.model.UserDao;
import com.backenduser.model.UserDto;
import com.backenduser.repository.UserRepository;
import com.backenduser.service.JwtUserDetailsService;
class JwtAuthenticationTests {
    @Mock
    private AuthenticationManager authenticationManager;
    @Mock
    private JwtTokenUtil jwtTokenUtil;
    @Mock
    private JwtUserDetailsService userDetailsService;
    @Mock
    private UserRepository userRepository;
    @InjectMocks
    private JwtAuthentication jwtAuthentication;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetUserByID_ValidToken() {
        when(jwtTokenUtil.getUsernameFromToken("testToken")).thenReturn("testUser");
        when(userDetailsService.getUser(1L)).thenReturn(Optional.of(new UserDao()));
        ResponseEntity<?> responseEntity = jwtAuthentication.getUserByID(1L, "Bearer testToken");
        assertEquals(200, responseEntity.getStatusCodeValue());
    }
    @Test
    void testGetUserByID_InvalidToken() {
        ResponseEntity<?> responseEntity = jwtAuthentication.getUserByID(1L, "InvalidToken");
        assertEquals(200, responseEntity.getStatusCodeValue());
        assertEquals("Not Authorised", responseEntity.getBody());
    }
}