package com.backendusertest;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendMicroserviceTests {


	void contextLoads() {
	}

}
