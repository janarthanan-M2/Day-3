package com.backenduser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendMicroservice {

	public static void main(String[] args) {
		SpringApplication.run(BackendMicroservice.class, args);
	}

}
