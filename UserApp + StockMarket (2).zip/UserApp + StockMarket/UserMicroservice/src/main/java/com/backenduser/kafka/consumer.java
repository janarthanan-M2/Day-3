//package com.backenduser.kafka;
//
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Service;
//
//@Service
//public class consumer
//{
//    @KafkaListener(topics="auth", groupId="kafkagroup")
//    public void consumeFromTopic(String message)
//
//    {
//        System.out.println("Message from User service:  "+ message);
//
//    }
//
//}