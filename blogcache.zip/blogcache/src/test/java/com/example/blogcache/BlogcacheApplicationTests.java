package com.example.blogcache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogcacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
