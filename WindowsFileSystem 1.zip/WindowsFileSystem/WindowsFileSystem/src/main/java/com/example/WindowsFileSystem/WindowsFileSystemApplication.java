package com.example.WindowsFileSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WindowsFileSystemApplication {

	public static void main(String[] args) {

		FileSystemApplication.File document = new FileSystemApplication.File("Application.txt");
		FileSystemApplication.File image = new FileSystemApplication.File("photo.jpg");


		FileSystemApplication.Directory root = new FileSystemApplication.Directory("user");
		FileSystemApplication.Directory documents = new FileSystemApplication.Directory("Appliactions");


		documents.addComponent(document);
		documents.addComponent(image);


		root.addComponent(documents);


		root.showDetails();
	}
}
