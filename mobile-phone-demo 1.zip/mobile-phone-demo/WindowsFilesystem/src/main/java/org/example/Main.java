package org.example;

public class Main {
    public static void main(String[] args) {

        FileSystemApplication.File document = new FileSystemApplication.File("Application.txt");
        FileSystemApplication.File image = new FileSystemApplication.File("photo.jpg");


        FileSystemApplication.Directory root = new FileSystemApplication.Directory("user");
        FileSystemApplication.Directory documents = new FileSystemApplication.Directory("Appliactions");


        documents.addComponent(document);
        documents.addComponent(image);


        root.addComponent(documents);


        root.showDetails();
    }
}